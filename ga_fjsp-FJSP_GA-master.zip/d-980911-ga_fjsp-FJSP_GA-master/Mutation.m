function [ Children_group2 ] = Mutation( Parent,PopSize,Pm,BestChromosome,len_of_chromosome,num_of_jobs,steps_of_job,machine_of_job )
 %% Mutation 
Children_group1=Parent;
    Children_group2=cell(PopSize,1);
    for i=1:(PopSize-1)
       temp_chromsome = Children_group1{i};
       %% Mutation for steps
        if rand(1)<Pm
            for j=1:4
                pos1=randi([1,len_of_chromosome]); % Choose the sequence number of a gene to be mutated
                pos2=randi([1,len_of_chromosome]); %  Choose another the sequence number of a gene to be mutated
                Gene=temp_chromsome(1,pos1); 
                temp_chromsome(1,pos1)=temp_chromsome(1,pos2);
                temp_chromsome(1,pos2)=Gene;
            end
        end
       %% Mutation for machine
       if rand(1)<Pm
           for k=1:4
               job = randi([1,num_of_jobs]) ;                                  %random choose job
               tempstep = randi([1,steps_of_job(job)]);                            %random choose step
               newmachine = machine_of_job{job}{tempstep}(randi([1,length(machine_of_job{job}{tempstep})]));%random choose machine
               temp_chromsome(2,sum(steps_of_job(1:job-1))+tempstep)= newmachine;     %replace the old one
           end
       end
       Children_group2{i} = temp_chromsome;    
    end
    Children_group2{PopSize}= BestChromosome;
    % complete mutation
end

