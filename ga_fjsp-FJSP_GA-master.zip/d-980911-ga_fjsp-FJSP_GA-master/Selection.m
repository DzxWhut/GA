function [ BestChromosome,Parent ] = Selection( Population,FITNESS,PopSize )
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    BestFitness=min(FITNESS);                                              % find the best chromosome
    position=find(FITNESS==BestFitness);                                   % and the position,may be more than one
    BestChromosome=Population{position(1)};                                % choose one chromosome from population   
    %% Selection :Elitism and 2-tournament selection are used
    Parent = cell(PopSize,1);
    Pr =0.8;
    for index =1:PopSize-1
        pos = randperm(PopSize,2);
        chromosome1 = Population{pos(1)};
        chromosome2 = Population{pos(2)};
        if (rand(1)<Pr) && FITNESS(pos(1))>FITNESS(pos(2))
                chromosome = chromosome1;
        else
                chromosome = chromosome2;
        end
        Parent{index} = chromosome;
    end
        Parent{PopSize}=BestChromosome;    
end

