clc
clear
%% ��ʼ����
load data;
num_mac=8;
PopSize=100;
maxGen=150;
Pc=0.8;
Pm=0.2;
%% ��ʼ��
[ Population,len_of_chromosome,num_of_jobs,steps_of_job,machine_of_job ] = Coding( T,PopSize );
%% ����
Cmax=zeros(1,PopSize);
for i=1:PopSize
    Chromosome=Population{i};
    [ Cmax(i) ] = FitnessCalculator( T,Chromosome );
end
[~,pos]=min(Cmax);
BestChromosome=Population{pos};
Parent=Population;
Obj=zeros(1,PopSize);
%% ����
for gen=1:maxGen
    gen
    %����
    [ Children_group1 ] = Cross( Parent,PopSize,Pc,BestChromosome,len_of_chromosome,num_of_jobs,T );
    %����
    [ Parent ] = Mutation( Children_group1,PopSize,Pm,BestChromosome,len_of_chromosome,num_of_jobs,steps_of_job,machine_of_job );
    %������Ӧ��
    Cmax=zeros(1,PopSize);
    for i=1:PopSize
        Chromosome=Parent{i};
        [ Cmax(i) ] = FitnessCalculator( T,Chromosome );
    end
    %ѡ��
    [ BestChromosome,Population ] = Selection( Parent,Cmax,PopSize );
    Parent=Population;
    Obj(gen)= min(Cmax);
end
    x=1:maxGen;
    plot(x,Obj)
%% ������ͼ
 [Jobs,Cmax1,MachineList,ST,PT] = SemiActiveDecoding(T,BestChromosome);
     chrom_job=BestChromosome(1,:);
     chrom_mac=BestChromosome(2,:);
     color=[1,0,0;
         0,1,0;
         0,0,1;
         1,1,0;
         0,1,1;
         1,0,1;
         1,0.5,0;
         0.67,1,0;
         0.63,0.13,0.94;
         0.94,0.9,0.55;         
         ];
figure(2)
Decode=[];
for s=1:27
    n_job_id=chrom_job(s);
    Decode=[Decode,n_job_id];
    n_sequ_id=sum(Decode==n_job_id);
    rec(1)=ST(s);
    pos=sum(steps_of_job(1:n_job_id-1))+n_sequ_id;
    rec(2)=chrom_mac(pos);
    rec(3)=PT(s);
    rec(4)=0.4;
    txt=sprintf('%d-%d=%d',n_job_id,n_sequ_id,PT(s));
   rectangle('Position',rec,'LineWidth',0.5,'LineStyle','-','FaceColor',[color(n_job_id,1),color(n_job_id,2),color(n_job_id,3)]);%draw every rectangle 
   text(ST(s)+0.2,(chrom_mac(pos)+0.2),txt,'FontWeight','Bold','FontSize',9);%label the id of every task  ��������������������
end