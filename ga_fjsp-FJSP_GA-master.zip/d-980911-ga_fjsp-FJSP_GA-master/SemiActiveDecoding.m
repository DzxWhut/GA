function [Jobs,Cmax,MachineList,ST,PT] = SemiActiveDecoding(T,Chromosome)
%UNTITLED4 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
%% start
num_of_jobs = length(T);                                                   %number of jobs
num_of_machines = length(T{1}{1});                                         %number of machines
len_of_chromosome = length(Chromosome);
StepList = [];                                                             %steps for all genes
MachineList = zeros(1,len_of_chromosome);
ST = zeros(1,len_of_chromosome);
PT = zeros(1,len_of_chromosome);
DecodedGenes =[];
steps_of_job =[];                                                       
for i = 1:num_of_jobs
    steps_of_job=[steps_of_job;length(T{i})];
end
               
%% Caculate MachineList and PT
for index = 1:len_of_chromosome
    DecodedGenes=[DecodedGenes Chromosome(1,index)];
    postion = length(find(DecodedGenes==Chromosome(1,index))); 
    StepList = [StepList postion];
    MachineList(index)=Chromosome(2,sum(steps_of_job(1:(Chromosome(1,index)-1)))+postion);
    PT(index)=T{Chromosome(1,index)}{postion}(MachineList(index));
end
%% Caculate ST
Machines = unique(MachineList);
Jobs = unique(Chromosome(1,:));
job_start_time = cell(num_of_jobs,1);
job_end_time = cell(num_of_jobs,1);
machine_start_time = cell(num_of_machines,1);
machine_end_time   = cell(num_of_machines,1);
machine_state = zeros(1,num_of_machines);                                %0--FirstWork;1--NotFirst 


for index = 1:len_of_chromosome
    job = Chromosome(1,index);
    machine = MachineList(index);
    pt = PT(index);
    step = StepList(index);
    pos_m = find(Machines==machine);
    pos_j = find(Jobs==job);
    if step==1                                                             %first step without considering the constrains between steps of same job
        if machine_state(pos_m)==0                                         % The machine is first used
            job_start_time{pos_j}=[0,pos_m];
            job_end_time{pos_j}=[job_start_time{pos_j}(1)+pt,pos_m]; 
        else
            job_start_time{pos_j}=[machine_end_time{pos_m}(1),pos_m];
            job_end_time{pos_j}=[job_start_time{pos_j}(1)+pt,pos_m];
        end
    else
         if machine_state(pos_m)==0                                         % The machine is first used
            job_start_time{pos_j}=[job_end_time{pos_j}(1),pos_m];
            job_end_time{pos_j}=[job_start_time{pos_j}(1)+pt,pos_m];   
        else
            job_start_time{pos_j}=[max(machine_end_time{pos_m}(1),job_end_time{pos_j}(1)),pos_m];
            job_end_time{pos_j}=[job_start_time{pos_j}(1)+pt,pos_m];
        end             
    end
    machine_start_time{pos_m}= job_start_time{pos_j}(1);
    machine_end_time{pos_m} = job_end_time{pos_j}(1); 
    machine_state(pos_m)=1;
    ST(index)=job_start_time{pos_j}(1); 
end

%% Caculate Cmax
end_time=cell2mat(job_end_time);
Cmax = max(end_time(:,1));
end

