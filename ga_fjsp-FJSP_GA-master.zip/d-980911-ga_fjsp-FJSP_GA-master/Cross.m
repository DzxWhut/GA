function [ Children_group1 ] = Cross( Parent,PopSize,Pc,BestChromosome,len_of_chromosome,num_of_jobs,T )
Children_group1=cell(PopSize,1);
for i=1:(PopSize-1)
    %Parent individuals are selected for crossover operation:
    %Parent1 is selected sequentially and Parent2 is selected randomly.
    index_parent2 = randi([1,(PopSize-1)]);
    Parent1=Parent{i};
    Parent2=Parent{index_parent2};
    Children1=zeros(2,len_of_chromosome);
    Children2=zeros(2,len_of_chromosome);
    if rand(1)<=Pc %Use the probability to determine if crossover is required
        %% Part1: IPX for step
        %Randomly divide the set of jobs {1,2,3...,n} into two non-empty sub-sets J1 and J2.
        num_J1 = randi([1,num_of_jobs]);
        if num_J1==num_of_jobs
            num_J1 = fix(num_of_jobs/2);
        end
        J = randperm(num_of_jobs);
        J1 =J(1:num_J1);
        J2 =J(num_J1+1:num_of_jobs);
        % Copy the jobs that Parent1 contains in J1 to Children1,
        % and Parent2 contains in J2 to Children2, and keep them in place.
        for index = 1:num_J1                                            % look for jobs that Parent1 are included in J1
            job = J1(index);
            for j = 1:len_of_chromosome
                if job == Parent1(1,j)
                    Children1(1,j)=Parent1(1,j);
                end
            end
        end
        for index = 1:num_of_jobs-num_J1                                % look for jobs that Parent2 are included in J2
            job = J2(index);
            for j = 1:len_of_chromosome
                if job == Parent2(1,j)
                    Children2(1,j)=Parent2(1,j);
                end
            end
        end
        %Copy the jobs that Parent1 contains in J1 to Children2,
        %and Parent2 contains in J2 to Children1 in their order.
        for index = 1:len_of_chromosome                                            % look for jobs that Parent1 are included in J1
            job = Parent1(1,index);
            if ~isempty(find(J1==job, 1))
                for gene = 1:len_of_chromosome
                    if Children2(1,gene)==0
                        Children2(1,gene)=job;
                        break;
                    end
                end
            end
        end
        for index = 1:len_of_chromosome                                            % look for jobs that Parent1 are included in J1
            job = Parent2(1,index);
            if ~isempty(find(J2==job, 1))
                for gene = 1:len_of_chromosome
                    if Children1(1,gene)==0
                        Children1(1,gene)=job;
                        break;
                    end
                end
            end 
        end
        %%IPOX cross operation completed
        %% Part 2 MPX for machine
        rand0_1 = zeros(1,len_of_chromosome);
        for gene = 1:len_of_chromosome
            if rand(1)>0.5
                rand0_1(gene)=1;
            end
        end 
        for gene = 1:len_of_chromosome
            if rand0_1(gene)==1
                Children1(2,gene) = Parent2(2,gene);
                Children2(2,gene) = Parent1(2,gene);
            else
                Children1(2,gene) = Parent1(2,gene);
                Children2(2,gene) = Parent2(2,gene);
            end
        end
        %MOX cross operation completed
    else
        Children1 = Parent1;
        Children2 = Parent2;
    end
    %% Select the Fitness value best retained to the next generation
    [Parent1_FitnessValue] = FitnessCalculator(T,Parent1);
    [Parent2_FitnessValue] = FitnessCalculator(T,Parent2);
    [Children1_FitnessValue] = FitnessCalculator(T,Children1);
    [Children2_FitnessValue] = FitnessCalculator(T,Children2);
    [~, pos] = min([Parent1_FitnessValue Parent2_FitnessValue Children1_FitnessValue Children2_FitnessValue]);
    temp_group ={Parent1 Parent2 Children1 Children2};
    Children_group1{i}=temp_group{pos};
end
 Children_group1{PopSize}= BestChromosome;
end

